﻿// DlalogCodeView.cpp: 实现文件
//

#include "pch.h"
#include "WindowsTools.h"
#include "DlalogCodeView.h"
#include "afxdialogex.h"


// DlalogCodeView 对话框

IMPLEMENT_DYNAMIC(DlalogCodeView, CDialogEx)

DlalogCodeView::DlalogCodeView(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG_CODEVIEW, pParent)
{

}

DlalogCodeView::~DlalogCodeView()
{
}

void DlalogCodeView::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_SOLUTION, ComboSolution);
}


BEGIN_MESSAGE_MAP(DlalogCodeView, CDialogEx)
	ON_CBN_SELCHANGE(IDC_COMBO_SOLUTION, &DlalogCodeView::OnCbnSelchangeComboSolution)
END_MESSAGE_MAP()


// DlalogCodeView 消息处理程序


BOOL DlalogCodeView::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  在此添加额外的初始化
	if (CodesNumber > 0)
	{
        for (int i = 0; i < CodesNumber; i++)
        {
            ComboSolution.AddString(Titles[i]);
        }
	}
	return TRUE;  // return TRUE unless you set the focus to a control
				  // 异常: OCX 属性页应返回 FALSE
}


void DlalogCodeView::OnCbnSelchangeComboSolution()
{
	// TODO: 在此添加控件通知处理程序代码
	int CurSel = ComboSolution.GetCurSel();
	CString a;
}
